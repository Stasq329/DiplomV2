package rfict.diplom.medicalassistantv20;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import java.util.ArrayList;

public class Complaints extends AppCompatActivity  {
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Complaints Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://rfict.diplom.medicalassistantv20/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Complaints Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://rfict.diplom.medicalassistantv20/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }

    public static enum TransitionType {SlideLeft}

    public static TransitionType transitionType;

    Button btn6;
    Button btn2;
    Button btn5;
    Button btn4;
    TextView diagnoz;
    final static int RQS_RECORDING = 1;

    Uri savedUri;
    EditText infoTextView;

    @Override


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.complaints);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        btn6 = (Button) findViewById(R.id.button6);
        btn2 = (Button) findViewById(R.id.button2);
       // btn5 = (Button) findViewById(R.id.button5);
        btn4 = (Button) findViewById(R.id.button4);
        btn6.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(Complaints.this, Spisok.class);
                startActivity(intent);
            }
        });


        String user;
        user = getIntent().getExtras().getString("username");
        EditText infoTextView = (EditText) findViewById(R.id.editText3);
        infoTextView.setText(user);


// Создаём пустой массив для хранения имен котов

        ListView listView = (ListView) findViewById(R.id.countriesList);
        final ArrayList<String> catnames = new ArrayList<String>();

        // Создаём адаптер ArrayAdapter, чтобы привязать массив к ListView
        final ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, catnames);
       // android.R.layout.simple_list_item_multiple_choice, catnames);
        // Привяжем массив через адаптер к ListView
        listView.setAdapter(adapter);



        final String simptom1 = "кашель";
        final String simptom2 = "гланды";
        final String simptom3 = "энурез";
        final String simptom4 = "лимфоузлы";
        final String simptom5 = "усталость";
        final String simptom6 = "сыпь";
        final String simptom7 = "охриплость";
        final String simptom8 = "вялость";
        final String simptom9 = "судороги";
        final String simptom10 = "температура";
        final String simptom11 = "живот";
        final String simptom12 = "голова";
        final String simptom13 = "насморк";
        final String simptom14 = "расстройство";
        final String simptom15 = "сопли";

        btn2.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View arg0) {
               EditText infoTextView = (EditText) findViewById(R.id.editText3);
                String data = infoTextView.getText().toString();
                String[] items = data.split(" ");
                for (String item : items) {

                    if (item.toString().equals(simptom1) || item.toString().equals(simptom2) || item.toString().equals(simptom3) || item.toString().equals(simptom4) || item.toString().equals(simptom5) || item.toString().equals(simptom6) || item.toString().equals(simptom7) || item.toString().equals(simptom8) || item.toString().equals(simptom9) || item.toString().equals(simptom10) || item.toString().equals(simptom11) || item.toString().equals(simptom12) || item.toString().equals(simptom13) || item.toString().equals(simptom14) || item.toString().equals(simptom15)) {
                        catnames.add(0, item.toString());
                        adapter.notifyDataSetChanged();
                    }

                }
            }



        });


        btn4.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                /*
                EditText infoTextView = (EditText) findViewById(R.id.editText3);
                String data = infoTextView.getText().toString();
                String[] items = data.split(" ");
                for (String item : items) {
                    if (item.toString().equals(simptom13) || item.toString().equals(simptom15)) {
                        Toast.makeText(Complaints.this, "Диагноз: Простуда ", Toast.LENGTH_SHORT).show();//**alter for your Activity name***
                    } else if (item.toString().equals(simptom10) || item.toString().equals(simptom5) || item.toString().equals(simptom1)) {
                        Toast.makeText(Complaints.this, "Диагноз: Грипп ", Toast.LENGTH_SHORT).show();//**alter for your Activity name***
                    }
                }
                */
                EditText infoTextView = (EditText) findViewById(R.id.editText3);
                String data = infoTextView.getText().toString();
                String[] ordinals = {"кашель в животе", "живот"};
                for (String ord : ordinals) {
                    if (data.contains(ord)) {
                        catnames.add(0, ord.toString());
                        adapter.notifyDataSetChanged();
                        Toast.makeText(Complaints.this, "Диагноз: Простуда ", Toast.LENGTH_SHORT).show();//**alter for your Activity name***
                        break;
                    }
                }


            }
  });








        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem action_settings2 = menu.findItem(R.id.action_settings2);
        action_settings2.setVisible(false);
        MenuItem action_settings3 = menu.findItem(R.id.action_settings3);
        action_settings3.setVisible(false);
        MenuItem Vizov3 = menu.findItem(R.id.Vithov3);
        Vizov3.setVisible(false);
        return super.onPrepareOptionsMenu(menu);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();


        switch (id) {
            case R.id.action_settings:
                Intent intent = new Intent(this, Settings.class);
                startActivity(intent);
                transitionType = TransitionType.SlideLeft;
                overridePendingTransition(R.anim.slide_left_in, R.anim.slide_left_out);

                break;
            case R.id.Vithov:
                intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:12345"));
                startActivity(intent);
                transitionType = TransitionType.SlideLeft;
                overridePendingTransition(R.anim.slide_left_in, R.anim.slide_left_out);
                break;


        }

        return super.onOptionsItemSelected(item);
    }


}