package rfict.diplom.medicalassistantv20;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class Rezerv extends AppCompatActivity {
    public static enum TransitionType {SlideLeft}
    public static TransitionType transitionType;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        long userId=0;
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            userId = extras.getLong("id");
        }

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, PlaceholderFragment.newInstance(userId))
                    .commit();
        }
    }

    public static class PlaceholderFragment extends Fragment {

        TextView nameBox;
        TextView yearBox;
        TextView telBox;
        TextView adrBox;


        TextView polBox;
        TextView invBox;
        TextView lgtBox;
        TextView osmBox;

        DatabaseHelper sqlHelper;
        SQLiteDatabase db;
        Cursor userCursor;

        public static PlaceholderFragment newInstance(long id) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args=new Bundle();
            args.putLong("id", id);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setRetainInstance(true);

            sqlHelper = new DatabaseHelper(getActivity());
        }
        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.karta, container, false);
            nameBox = (TextView) rootView.findViewById(R.id.name);
            yearBox = (TextView) rootView.findViewById(R.id.year);
            telBox = (TextView) rootView.findViewById(R.id.tel);
            adrBox = (TextView) rootView.findViewById(R.id.adr);


            polBox = (TextView) rootView.findViewById(R.id.pol);
            lgtBox = (TextView) rootView.findViewById(R.id.lgt);
            invBox = (TextView) rootView.findViewById(R.id.inv);
            osmBox = (TextView) rootView.findViewById(R.id.textView5);



            final long id = getArguments() != null ? getArguments().getLong("id") : 0;

            db = sqlHelper.getWritableDatabase();




            // если 0, то добавление
            if (id > 0) {
                // получаем элемент по id из бд
                userCursor = db.rawQuery("select * from " + DatabaseHelper.TABLE + " where " +
                        DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(id)});
                userCursor.moveToFirst();

                nameBox.setText(userCursor.getString(1));
                yearBox.setText(String.valueOf(userCursor.getInt(2)));
                telBox.setText(userCursor.getString(3));
                adrBox.setText(userCursor.getString(4));


                polBox.setText(userCursor.getString(5));
                invBox.setText(userCursor.getString(6));
                lgtBox.setText(userCursor.getString(7));
                osmBox.setText(userCursor.getString(8));
                //

                userCursor.close();

            }
            return rootView;
        }

        public void goHome(){
            // закрываем подключение
            db.close();
            // переход к главной activity
            Intent intent = new Intent(getActivity(), Spisok.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);

        }
    }
}