package rfict.diplom.medicalassistantv20;


import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import android.content.ContentValues;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "userstore.db"; // название бд
    private static final int SCHEMA = 1; // версия базы данных
    static final String TABLE = "users"; // название таблицы в бд
    // названия столбцов
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_YEAR = "year";
    public static final String COLUMN_TEL = "tel";
    public static final String COLUMN_ADR = "adr";

    public static final String COLUMN_POL = "pol";
    public static final String COLUMN_INV = "inv";
    public static final String COLUMN_LGT = "lgt";
    public static final String COLUMN_OSM = "osm";



    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, SCHEMA);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE users (" + COLUMN_ID
                + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_NAME
                + " TEXT, " + COLUMN_YEAR + " INTEGER,  " + COLUMN_TEL + " TEXT, " + COLUMN_ADR + " TEXT, " + COLUMN_POL + " TEXT, " + COLUMN_INV + " TEXT, " + COLUMN_LGT + " TEXT, " + COLUMN_OSM + " TEXT );");
        // добавление начальных данных
        db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME
                + ", " + COLUMN_YEAR  + " , " + COLUMN_TEL  + " , " + COLUMN_ADR + ", " + COLUMN_POL + ", " + COLUMN_INV + ", " + COLUMN_LGT + ", " + COLUMN_OSM + ") VALUES ('Орешко Станислав', 1994, 1111111, 'Киселева 4-2', 'М', '-', '-', '12.04.16 Обращался с болями в животе'), ('Шмарловский Кирилл', 1993, 2222222, 'Проспект Независимости 43', 'М', 'Инвалид 3 группы', 'Осмотры без очередни', '10.01.16 Обращался с сильными болями в голове'), ('Пашкевич Юлия', 1993,'3333333', 'Улица Куйбышава 53-2', 'Ж', '-', '-', '15.02.16 Сдавала флюрографию. Патологий не обнаружено.');");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE);
        onCreate(db);
    }
}